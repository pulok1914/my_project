package com.notes.iit.simplenotesmanager;

import java.util.Date;

public class Note {
    public String description;
    public String date;

    public Note(String description, String date) {
        this.description = description;
        this.date = date;
    }
}
